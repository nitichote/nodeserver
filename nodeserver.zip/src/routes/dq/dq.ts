import * as express from 'express';
import { Router, Request, Response } from 'express';
import { Jwt } from '../../models/jwt';
const path = require('path');  // Make sure this line is present to import the path module

import * as HttpStatus from 'http-status-codes';
import { PutModel } from '../../models/putModel';
import Knex = require('knex');
import { log } from 'console';
var formidable = require('formidable');
var sharp = require('sharp');
//const jwt = new Jwt();
const jwt = require('jsonwebtoken');
var fs =require('fs');
const router: Router = Router();
const putmodel = new PutModel();

const SECRET_KEY = '12345';
/* router.get('/', (req: Request, res: Response) => {
  res.send({ ok: true, message: 'Welcome to RESTful api server!', code: HttpStatus.OK });
}); */
const db = Knex({
  client: 'mysql2',
  connection: {
    host: process.env.DB_HOST,
    port: +process.env.DB_PORT,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: 'dq2'
  }
 
/* DB_HOST=188.166.178.13 
DB_PORT=3306 
DB_NAME=db_dentalspec 
DB_USER=sampan 
DB_PASSWORD=7256284_admin 
SECRET_KEY=91234567890 
PORT=3002 */
});


var multer = require('multer');
// Configure storage
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    // Extract school_id, child_id, and service_id from the request
    const { school_id, child_id, service_id } = req.body;
    
    // Construct the directory path
    const dir = path.join(__dirname, 'uploads', school_id);
    
    // Ensure the directory exists (this requires the 'fs' module)
    require('fs').mkdir(dir, { recursive: true }, (err) => {
      cb(err, dir);
    });
  },
  filename: function (req, file, cb) {
    // Extract school_id, child_id, and service_id from the request
    const { child_id, service_id } = req.body;

    // Construct the file name
    const filename = `${child_id}_${service_id}_${Date.now()}${path.extname(file.originalname)}`;

    cb(null, filename);
  }
});

const upload = multer({ storage: storage });
//var upload = multer({ storage: storage })
router.post('/file', upload.single('file'),(req, res, next) =>{
  if (req.file) {
    console.log('File uploaded successfully:', req.file.path);
    res.status(200).send({ success: true, file: req.file });
  } else {
    console.log('File upload failed');
    res.status(500).send({ success: false, message: 'File upload failed' });
  }
  
});

var uploads = multer({ storage: storage }).array('userfiles', 10);


router.post('/upload', function (req, res) {
  uploads(req, res, function (err) {
      if (err instanceof multer.MulterError) {
        // A Multer error occurred when uploading.
        return res.status(500).json(err);
      } else if (err) {
        // An unknown error occurred when uploading.
        return res.status(500).json(err);
      }
      
      let uploadedFiles = [];
    
     //// for(let item of req['files']) {
     ///     uploadedFiles.push({filename: item.originalname});
    ////  }

      // Everything went fine.
      res.json({progress: 100, files: uploadedFiles});
  })
});


// new jwt###################
router.get('/api/encode/:pass',async (req: Request, res: Response) => {
  const pass = req.params.pass;
    try {
      const x = await req.bcrypt.hashPassword(pass);
      console.log("x=",x);
      
   res.send({x}) ;
   } catch (error) {
   // Handle database error
   console.error(error);
   res.status(500).send({ message: 'Server error' });
   }
   // res.send({ ok: false, message: 'Error Connect to Database is.' });
 });
router.post('/api/auth/login',async (req: Request, res: Response) => {
  const { username, password } = req.body;
  console.log("user=",username);
  // Assume a user object for demonstration
  let db = req.db16;
  
  try {
    // sql = `select * from pt where hcode=${hcode}`;
    //const sql = `select * from user where username='${username}' and password='${password}' `;
     //const rows = await db.raw(sql);
     const rows = await db('user')
  .where({
    username: username,
    password: password
  })
  .select('*');
     console.log(rows[0]);
     console.log("u=",rows[0].username);
     console.log("u2=",rows[0]['username']);
     console.log("p=",rows[0].password);
     if (rows.length === 0 || rows[0].password !== password) {
      console.log("pass=",rows[0].password);
      
      return res.status(401).send({ message: 'Invalid username or password' });
    }
console.log("ok now");

    // User found and password matches
    const hcode = rows[0].hcode;
   const sql2 = `select * from hospitalcpho where off_id=${hcode}`;
    //const sql = `select * from user where username='${username}' and password='${password}' `;
    const rows2 = await db.raw(sql2);
    const hos = rows2[0][0];

    const user = {
      uid: rows[0].uid,
      username: rows[0].username,
      hcode:rows[0].hcode,
      hname:hos.off_name,
      htype:hos.off_type,
    };

    // Generate JWT and send it back to the client
    const token = jwt.sign(user, SECRET_KEY, { expiresIn: '1h' });
    res.json({ token:token,user:JSON.stringify(user) });

   } catch (error) {
   // Handle database error
   console.error(error);
   res.status(500).send({ message: 'Server error' });
   }
   // res.send({ ok: false, message: 'Error Connect to Database is.' });
 });

 

  // TODO: Validate username and password




// Middleware to check JWT
function checkJWT(req, res, next) {
  const btoken = req.headers['authorization'];
  let token=btoken;
  if(btoken.startsWith('Bearer ')) {
  token=btoken.split(' ')[1];
console.log('ntoken=',token);
  }
  if (!token) {
    return res.status(401).send({ message: 'Unauthorized' });
  }

  jwt.verify(token, SECRET_KEY, (err, user) => {
    if (err) {
      return res.sendStatus(403);
    }
    req.user = user;
    next();
  });
}

// new jwt ######################
router.post('/insertUpdate', async (req: Request, res: Response) => {
  let db = req.db16;
  let data = req.body.data;
  let tableName = data.tableName;
  let dataUpdate = data.whereName;
  let formData = data.formData;
 // console.log(data);

  try {
    let rows = await putmodel.insertData(db, tableName, formData);
    res.send({ ok: true, rows: rows, code: HttpStatus.OK });
  } catch (error) {
    console.log('okupdate');

    let rows = await putmodel.updateData(db, tableName, dataUpdate, formData);

    res.send({ ok: true, rows: rows, code: HttpStatus.OK });
  }
});

router.post('/insert', async (req: Request, res: Response) => {
  let db = req.db16;
  let data = req.body.data;
  let tableName = data.tableName;
  let dataInsert = data.formData;
  
  console.log("Received data for table:", tableName, "with data:", dataInsert);

  try {
    let rows = await db(tableName).insert(dataInsert);
    res.send({ ok: true, rows: rows, code: 200 });
  } catch (error) {
    console.error("Error inserting data:", error);
    res.send({ ok: false, message: 'Error connecting to the database.', code: 404 });
  }
});

router.post('/insert_origin', async (req: Request, res: Response) => {
  console.log("Received request:", req.body);
  let db = req.db16;
  let data = req.body.data;
  let tableName = data.tableName;
  let dataInsert = data.formData;
console.log("data=",data);
console.log("datains=",dataInsert);
//let formData = [{doctorname: "chote2"}];
//console.log("fs=",formData);
  try {
    let rows = await putmodel.insertData(db, tableName, dataInsert);
    res.send({ ok: true, rows: rows, code: HttpStatus.OK });
  } catch (error) {
    res.send({ ok: false, rows: error, code: HttpStatus.NOT_FOUND });
  }
});

router.post('/update', async (req: Request, res: Response) => {
  let db = req.db16;
  // รูปแบบข้อมูล
  //let formData = [{ id: 2, pname: '755555', lname: '999999' }]
  //let whereUpdate = [{ id: 2 }];
  let data = req.body.data;
  // let data = {
  //     tableName: tablename,
  //     whereUpdate: whereUpdate,
  //     formData: formData
  // };
  // console.log(data);
  let tableName = data.tableName;
  let dataUpdate = data.whereName;
  let formData = data.formData;
  try {
    let rows = await putmodel.updateData(db, tableName, dataUpdate, formData);
    res.send({ ok: true, rows: rows, personscode: HttpStatus.OK });
  } catch (error) {
    res.send({ ok: false, rows: error, code: HttpStatus.NOT_FOUND });
  }
});

router.post('/del', async (req: Request, res: Response) => {
  let db = req.db16;
  // รูปแบบข้อมูล
  let data = req.body.data;

  //console.log(data);

  let tableName = data.tableName;
  let dataUpdate = data.whereName;

  try {
    let rows = await putmodel.deleteData(db, tableName, dataUpdate);
    res.send({ ok: true, rows: rows, code: HttpStatus.OK });
  } catch (error) {
    res.send({ ok: false, rows: error, code: HttpStatus.NOT_FOUND });
  }
});

router.get('/q2', async (req: Request, res: Response) => {
  const db = req.db16;
  //console.log(db);
  try {
    const raw = await db.raw(`SELECT q.*,d.doctorname,c.instype_grpshortdesc FROM  qmain2 q LEFT JOIN doctor d on q.doctor_id = d.doctor_id left join co_insurancetype c on q.card_id = c.instype_grpid `);
    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({
      ok: false,
      message: error,
      error:error
    });
  }
  // res.send({ ok: false, message: 'ok Error Connect to Database isvv.' });
});
router.get('/doctors', async (req: Request, res: Response) => {
  const db = req.db16;
  let sql = '';
  
  try {
    //const raw = await db.raw(`select * from pt`);
    const rows = await db('doctor')
       .select('doctor_id','doctorname','isactive');
       res.send({ ok: true, rows });
     } catch (error) {
       //console.error(error);
       res.send({ ok: false, message: 'i have Error connecting to the database.' });
     } 
   });
router.get('/type', async (req: Request, res: Response) => {
  const db = req.db16;
  let sql = '';
  
  try {
    //const raw = await db.raw(`select * from pt`);
    const rows = await db('txtype')
       .select('type_id','typename');
          res.send({ ok: true, rows });
     } catch (error) {
       //console.error(error);
       res.send({ ok: false, message: 'i have Error connecting to the database.' });
     } 
   });
   
router.get('/card', async (req: Request, res: Response) => {
  const db = req.db16;
  let sql = '';
  
  try {
    //const raw = await db.raw(`select * from pt`);
    const rows = await db('co_insurancetype')
       .select('instype_grpid','instype_grpshortdesc');
       res.send({ ok: true, rows });
     } catch (error) {
       //console.error(error);
       res.send({ ok: false, message: 'i have Error connecting to the database.' });
     } 
   });
   router.get('/qmainTx/:type_id', async (req: Request, res: Response) => {
    const db = req.db16;
    const type_id = req.params.type_id;  // Assuming 'hcode' is provided through query parameters
    console.log('TYPE_ID:', type_id);
    try {
      if(type_id ==0){
      const rawQuery = `
        SELECT q.*, d.doctorname, c.instype_grpshortdesc 
        FROM qmain2 q
        LEFT JOIN doctor d ON q.doctor_id = d.doctor_id
        LEFT JOIN co_insurancetype c ON q.card_id = c.instype_grpid
      `;
      const rows = await db.raw(rawQuery);  // Safe parameter binding
      res.send({ ok: true, rows: rows[0] });
    }else{
      const rawQuery = `
      SELECT q.*, d.doctorname, c.instype_grpshortdesc 
      FROM qmain2 q
      LEFT JOIN doctor d ON q.doctor_id = d.doctor_id
      LEFT JOIN co_insurancetype c ON q.card_id = c.instype_grpid
      WHERE q.hcode = ?
    `;
    const rows = await db.raw(rawQuery, [type_id]);  // Safe parameter binding
    res.send({ ok: true, rows: rows[0] });

      }
      // Adjust depending on DB driver and Knex version
    } catch (error) {
      console.error(error);
      res.send({ ok: false, message: 'i have Error connecting to the database.' });
    }
  });
  router.post('/login', async (req: Request, res: Response) => {
    const db = req.db16;  // Assuming db is set on locals in app configuration
    const { user: username, password } = req.body;
    console.log(req.body);
    console.log("user=",username,"password=",password);
    try {
      const rawQuery = `
        SELECT * FROM userregist WHERE username = ? LIMIT 1
      `;
      const  result = await db.raw(rawQuery, [username]);
      const  rows = result[0]; 
      if (rows.length > 0) {
        const userRecord = rows[0]; 
        console.log("userRecord=", userRecord);
        console.log("userRecord.password=", userRecord.password);  // Correctly access 'password' from 'userRecord'
      //  const validPassword = await req.bcrypt.compare(password, user.password);  // Assuming user.password is hashed
    //  const validPassword = password == user.password;
      if (password == userRecord.password) {
          res.send({ ok: true, user: {  username: userRecord.username,hcode:userRecord.hcode,hname:userRecord.hname } });  // Avoid sending back the password or sensitive info
        } else {

          res.send({ ok: false, message: 'Incorrect password.',data:{password:password,userpass:userRecord.password} });
        }
      } else {
        res.send({ ok: false, message: 'User not found.' });
      }
    } catch (error) {
      console.error(error);
      res.send({ ok: false, message: 'Error connecting to the database.' });
    }
  });
  
  router.get('/logins/:user/:password', async (req: Request, res: Response) => {
    const db = req.db16;
    const user = req.params.user;  // Assuming 'hcode' is provided through query parameters
    const password = req.params.password; 
   
    try {
      const rawQuery = `
        SELECT * from userregist WHERE user = ? and password =? 
      `;
      const rows = await db.raw(rawQuery, [user],[password]);  // Safe parameter binding
  
      res.send({ ok: true, rows: rows[0] }); // Adjust depending on DB driver and Knex version
    } catch (error) {
      console.error(error);
      res.send({ ok: false, message: 'i have Error connecting to the database.' });
    }
  });
  function getFiscalYearStart(year) {
    return `${year - 1}-10-01`; // Fiscal year starts on October 1st of the previous year
}

function getFiscalYearEnd(year) {
    return `${year}-09-30`; // Fiscal year ends on September 30th of the given year
}

// Example usage for the year 2024
const fiscalYearStart = getFiscalYearStart(2024);
const fiscalYearEnd = getFiscalYearEnd(2024);
   router.get('/qmain2/:hcode/:year', async (req: Request, res: Response) => {
    console.log("rawQueryee=");
    const db = req.db16;
    const hcode = req.params.hcode;  // Assuming 'hcode' is provided through query parameters
    const year = req.params.year;
    console.log('HCODE:', year);
    const fiscalYearStart = getFiscalYearStart(year);
const fiscalYearEnd = getFiscalYearEnd(year);
    try {
      const rawQuery = `
    SELECT q.*, d.doctorname, c.instype_grpshortdesc,
    CONCAT(q.fname, ' ', q.lname, '(', CAST(q.age AS CHAR), ')') AS nameage
FROM qmain q
LEFT JOIN doctor d ON q.doctor_id = d.doctor_id
LEFT JOIN co_insurancetype c ON q.card_id = c.instype_grpid
WHERE q.hcode = ?
ORDER BY q.registerdate DESC
`;

      console.log("rawQuery=",rawQuery);
      const rows = await db.raw(rawQuery, [hcode]);  // Safe parameter binding
  
      res.send({ ok: true, rows: rows[0] }); // Adjust depending on DB driver and Knex version
    } catch (error) {
      console.error("error=",error);
      res.send({ ok: false, message: 'i have Error connecting to the database.' });
    }
  });
router.get('/qmain3/hcode', async (req: Request, res: Response) => {
  const db = req.db16;
  const hcode = req.query.hcode;  // Assuming 'hcode' is passed as a query parameter

  try {
    const rows = await db('qmain2 as q')
      .select('q.*', 'd.doctorname', 'c.instype_grpshortdesc')
      .leftJoin('doctor as d', 'q.doctor_id', 'd.doctor_id')
      .leftJoin('co_insurancetype as c', 'q.card_id', 'c.instype_grpid')
      .where('q.hcode', '=', hcode);  // Add the where clause here

    res.send({ ok: true, rows });
  } catch (error) {
    console.error(error);
    res.send({ ok: false, message: 'i have Error connecting to the database.' });
  }
   });


router.get('/cacode', async (req: Request, res: Response) => {
  const db = req.db16;
  let sql = '';
  
  try {
    //const raw = await db.raw(`select * from pt`);
    const rows = await db('cacode')
       .select('*');
       res.send({ ok: true, rows });
     } catch (error) {
       console.error(error);
       res.send({ ok: false, message: 'Error connecting to the database.' });
     } 
   });
  // res.send({ ok: false, message: 'Error Connect to Database is.' });
  router.get('/ocancers/:cid', async (req: Request, res: Response) => {
    const db = req.db16;
    let sql = '';
    let cid=req.params.cid;
    try {
      //const raw = await db.raw(`select * from pt`);
      const rows = await db('ocancer as o')
      .where('o.cid', 'like', cid)
      .select('o.*', 'h.off_name as referhosname','h1.off_name as ophosname','c1.codename as pmdsname','c2.codename as biopsyname','c3.codename as cancername') // Replace 'fieldA' and 'fieldB' with your actual field names
      .leftJoin('hospitalcpho as h', 'o.referto', '=', 'h.off_id') // Replace 'commonField' with the field you're joining on
      .leftJoin('hospitalcpho as h1', 'o.hcode', '=', 'h1.off_id')
      .leftJoin('cacode as c1', 'o.dg_pmds', '=', 'c1.code')
      .leftJoin('cacode as c2', 'o.biopsy', '=', 'c2.code')
      .leftJoin('cacode as c3', 'o.dg_cancer', '=', 'c3.code');
      res.send({ ok: true, rows });
       } catch (error) {
         console.error(error);
         res.send({ ok: false, message: 'Error connecting to the database.' });
       } 
     });
    // res.send({ ok: false, message: 'Error Connect to Database is.' });
router.get('/hosmain', async (req: Request, res: Response) => {
  const bcrypt=req.bcrypt;
  const db = req.db16;
  let hcode=req.params.hcode;
  // const hcode = "11"//req.params.hcode;
  try {
   //const raw = await db.raw(`select * from pt`);
   const rows = await db('hospitalcpho')
   .select('off_id', 'off_name')
   .where('off_name', 'like', 'โรงพยาบาล%')
      res.send({ ok: true, rows });
    } catch (error) {
      console.error(error);
      res.send({ ok: false, message: 'Error connecting to the database.' });
    } 
  });
router.get('/ptsearch/:txt/:hcode',checkJWT, async (req: Request, res: Response) => {
  const bcrypt=req.bcrypt;
  const db = req.db16;
  let txt=req.params.txt;
  let hcode=req.params.hcode;
   console.log("ok=",hcode,"txt=",txt);
   
  const regex = /^\d{13}$/;
  if(regex.test(txt)){
  // const hcode = "11"//req.params.hcode;
  try {
    //const raw = await db.raw(`select * from pt`);
    const rows = await db('pt')
       .where({ hcode:hcode})
       .andWhere('cid', 'like', `%${txt}%`)  // replace 'txtsearchColumn' with the actual column name for txtsearch
       .select('*');
       res.send({ ok: true, rows });
     } catch (error) {
       console.error(error);
       res.send({ ok: false, message: 'Error connecting to the database.' });
     } 
  }
else{
  try {
    //const raw = await db.raw(`select * from pt`);
    const rows = await db('pt')
    .where({ hcode:hcode})
    .andWhere('ptname', 'like', `%${txt}%`)  // replace 'txtsearchColumn' with the actual column name for txtsearch
    .select('*');
       res.send({ ok: true, rows });
     } catch (error) {
       console.error(error);
       res.send({ ok: false, message: 'Error connecting to the database.' });
     } 

}
  });




router.post('/login', async (req: Request, res: Response) => {
  let db = req.db16;
  // รูปแบบข้อมูล
  let data = req.body;
let user = data.user;
let pass= data.pass;
let sql=`select *  from hospital36 where off_id='${user}' and pincode= '${pass}'`;
  try {
    const raw = await db.raw(sql);
    
    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.no ok' });
  }
});
router.post('/upload', async (req: Request, res: Response) => {
  let db = req.db16;
  // รูปแบบข้อมูล
  let data = req.body.data;
  console.log('รูปแบบข้อมูล');

  //console.log(data);
  try {
    var form = new formidable.IncomingForm();

    form.parse(req, (err, fields, files) => {
      console.log(files);

      let file_name = files.image.name;
      let file_path = files.image.path;
      let new_path = 'c:/d/images/' + file_name;
      sharp(file_path)
        .resize(150)
        .toFile(new_path, (err) => {
          if (!err) {
            res.send({ ok: true });
          } else {
            res.send({ ok: false });
          }
        });
    });
  } catch (err) {
    res.send({ ok: false, err: err.message });
  }
});
router.get('/', async (req: Request, res: Response) => {
  const db = req.db16;
  try {
    const raw = await db.raw('select * from patient limit 10');
    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({
      ok: false,
      message: 'there is an Error Connect to Database is.no ok',
    });
  }
  // res.send({ ok: false, message: 'ok Error Connect to Database isvv.' });
});
router.get('/table/:tbl', async (req: Request, res: Response) => {
  const db = req.db16;
  const tbl = req.params.tbl;
  try {
    const raw = await db.raw(`select * from ${tbl}`);
    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({
      ok: false,
      message: 'there is an Error Connect to Database is.no ok',
    });
  }
  // res.send({ ok: false, message: 'ok Error Connect to Database isvv.' });
});
router.get('/pts', async (req: Request, res: Response) => {
  const db = req.db16;
  try {
    const raw = await db.raw(`select *  from pt p,hospital36 h where p.hcode = h.off_id `);
    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({
      ok: false,
      message: 'there is an Error Connect to Database is.no ok',
    });
  }
  // res.send({ ok: false, message: 'ok Error Connect to Database isvv.' });
});
router.get('/pt1hos/:hcode', async (req: Request, res: Response) => {
  const db = req.db16;
  const hcode = req.params.hcode;
  try {
    const raw = await db.raw(`select *  from pt p,hospital36 h where p.hcode = h.off_id and hcode='${hcode}'`);
    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({
      ok: false,
      message: 'there is an Error Connect to Database is.no ok',
    });
  }
  // res.send({ ok: false, message: 'ok Error Connect to Database isvv.' });
});
router.get('/pt', async (req: Request, res: Response) => {
  const db = req.db16;
  try {
    const raw = await db.raw('select * from pt2006 limit 10');
    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({
      ok: false,
      message: 'there is an Error Connect to Database is.no ok',
    });
  }
  // res.send({ ok: false, message: 'ok Error Connect to Database isvv.' });
});
router.get('/pt/:hn', async (req: Request, res: Response) => {
  const db = req.db16;
  const key = req.params.key;
  const hn = req.params.hn;
  let sql = '';
  var char = hn.substring(0,1);;
let s  = /^[0-9]$/.test(char);   
  if (s) {
    sql = `select * from pt2006 where ptcode ='${hn}'`;
  } else {
    sql = `select * from pt2006 where flname like '%${hn}%'`;
  }
  console.log(sql);

  /* if (key == 'amp') {
        sql = 'select ampcode,ampname,avg(percent) as pc from ohsp group by ampcode';
     } */
  try {
    const raw = await db.raw(sql);

    res.send({ ok: true, message: raw[0] ,sql,char});
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.no ok' });
  }
  // res.send({ ok: false, message: 'Error Connect to Database is.' });
});
router.get('/patient/:hn', async (req: Request, res: Response) => {
  const db = req.db16;
  const key = req.params.key;
  const hn = req.params.hn;
  let sql = '';
  if (hn == 0) {
    sql = `select * from patient`;
  } else {
    sql = `select * from patient where hn='${hn}'`;
  }
  console.log(sql);

  /* if (key == 'amp') {
        sql = 'select ampcode,ampname,avg(percent) as pc from ohsp group by ampcode';
     } */
  try {
    const raw = await db.raw(sql);

    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.no ok' });
  }
  // res.send({ ok: false, message: 'Error Connect to Database is.' });
});
router.get('/gsearch/:con/:dname', async (req: Request, res: Response) => {
  const db = req.db16;
  const con = req.params.con;
  const dname = req.params.dname;
  //const reportid = req.params.reportid;
  let sql = `select * from dperson d inner join hospitalcpho h on d.officenow = h.off_id where dname like '%${dname}%'`;
  if (con == 'office') {
    sql = `select * from dperson d inner join hospitalcpho h on d.officenow = h.off_id where h.off_name like  '%${dname}%'`;
  }
  console.log(sql);

  /* if (key == 'amp') {
        sql = 'select ampcode,ampname,avg(percent) as pc from ohsp group by ampcode';
     } */
  try {
    const raw = await db.raw(sql);

    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.no ok' });
  }
  // res.send({ ok: false, message: 'Error Connect to Database is.' });
});
router.get('/offices', async (req: Request, res: Response) => {
  const db = req.db16;
  let sql = `select * from hospitalcpho where off_type in('03','05','06','07','12','13')`;
  /* if (key == 'amp') {
        sql = 'select ampcode,ampname,avg(percent) as pc from ohsp group by ampcode';
     } */
  try {
    const raw = await db.raw(sql);
    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.no ok' });
  }
});
router.get('/officesCpho', async (req: Request, res: Response) => {
  const db = req.db16;
  let sql = `select * from hospitalcpho where off_type in('01','03','05','06','07','12','13')`;
  /* if (key == 'amp') {
        sql = 'select ampcode,ampname,avg(percent) as pc from ohsp group by ampcode';
     } */
  try {
    const raw = await db.raw(sql);
    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.no ok' });
  }
});
router.get('/officeCpho1/:hcode', async (req: Request, res: Response) => {
  const db = req.db16;
  const hcode = req.params.hcode;
  let sql = `select * from hospitalcpho where off_type in('01','03','05','06','07','12','13') and off_id='${hcode}'` ;
  
  try {
    const raw = await db.raw(sql);
    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.no ok' });
  }
});
router.get('/officesSch', async (req: Request, res: Response) => {
  const db = req.db16;
  let sql = `select h.*,(select count(*)  from schooldata s where s.hcode = h.off_id) as cntSch   from hospitalcpho h where h.off_type in('03','','06','07','12','13')`;
  /* if (key == 'amp') {
        sql = 'select ampcode,ampname,avg(percent) as pc from ohsp group by ampcode';
     } */
  try {
    const raw = await db.raw(sql);
    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.no ok' });
  }
});
router.get('/school/show', async (req: Request, res: Response) => {
  const db = req.db16;
  let sql = `select * from schooldata s inner join ampall a on left(s.tamboncode,4) = a.code inner join hospitalcpho h on s.hcode = h.off_id `;
  /* if (key == 'amp') {
        sql = 'select ampcode,ampname,avg(percent) as pc from ohsp group by ampcode';
     } */
  try {
    const raw = await db.raw(sql);
    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.no ok' });
  }
});
router.get('/schoolenv/show', (req: Request, res: Response) => {
  const db = req.db16;
  
  let sql = `select s.schoolid,s.schname,s.tag,e.ip,e.lastupdate,e.userpin,e.toothbrush,e.isnocoke,e.isnosweet,e.isnocandy,e.rpyear,s.tamboncode,a.code,a.name,h.off_name,s.hcode from (select sc.* from schooldata sc inner join schclass c on sc.schoolid=c.schoolid where  c.m6=0 and sc.schtypecode='1001') s  inner join ampall a on left(s.tamboncode,4) = a.code inner join hospitalcpho h on s.hcode = h.off_id left outer join school_env e on s.schoolid = e.schoolid  and e.rpyear='2563' order by h.off_id,a.code `;
  //let sql = `select s.schoolid,s.schname,s.tag,s.tamboncode,a.code,a.name,h.off_name,s.hcode,e.* from schooldata s inner join ampall a on left(s.tamboncode,4) = a.code inner join hospitalcpho h on s.hcode = h.off_id left outer join school_env e on s.schoolid = e.schoolid and e.rpyear='2563' order by h.off_id,a.code `;
  
  db.raw(sql)
    .then((raw) => {
      res.send({ ok: true, message: raw[0] });
    })
    .catch((err) => {
      res.send({ ok: false, message: err.message });
    });
});

router.get('/tbl/:tbl', async (req: Request, res: Response) => {
  const db = req.db16;
  const tbl = req.params.tbl;
  let sql = `select * from ${tbl} `;
  try {
    const raw = await db.raw(sql);
    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.no ok' });
  }
});
router.get('/amp36', async (req: Request, res: Response) => {
  const db = req.db16;
  const tbl = req.params.tbl;
  let sql = `select * from ampall where left(code,2)=36 `;
  try {
    const raw = await db.raw(sql);
    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.no ok' });
  }
});
router.get(
  '/ohspsum/amp/:reportid/:ampcode',
  async (req: Request, res: Response) => {
    const db = req.db16;
    const ampcode = req.params.ampcode;
    const reportid = req.params.reportid;
    let sql = `select h.tamboncode ,avg(percent) as pc from ohsp o INNER JOIN chospital  h  on o.hcode = h.hoscode where o.id='${reportid}' and o.ampcode='${ampcode}' group by tamboncode`;
    /* if (key == 'amp') {
        sql = 'select ampcode,ampname,avg(percent) as pc from ohsp group by ampcode';
     } */
    try {
      const raw = await db.raw(sql);

      res.send({ ok: true, message: raw[0] });
    } catch (error) {
      res.send({ ok: false, message: 'Error Connect to Database is.no ok' });
    }
    // res.send({ ok: false, message: 'Error Connect to Database is.' });
  }
);
router.get('/ohsp', async (req: Request, res: Response) => {
  const db = req.db16;
  try {
    const raw = await db.raw(
      'select * from ohsp o INNER JOIN chospital  h  on o.hcode = h.hoscode'
    );
    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.no ok' });
  }
  // res.send({ ok: false, message: 'Error Connect to Database is.' });
});

router.get('/ohsp/:denttopicid', async (req: Request, res: Response) => {
  const db = req.db16;
  const id = req.params.denttopicid;
  try {
    const raw = await db.raw(
      `select * from ohsp o INNER JOIN chospital  h  on o.hcode = h.hoscode where o.denttopicid = ${id}`
    );

    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.no ok' });
  }
  // res.send({ ok: false, message: 'Error Connect to Database is.' });
});
router.get('/specpersons', async (req: Request, res: Response) => {
  const db = req.db16;
  try {
    const raw = await db.raw(
      'select * from specperson s inner join hospital h on s.hcode= h.hcode'
    );
    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.no ok' });
  }
  // res.send({ ok: false, message: 'Error Connect to Database is.' });
});
router.get('/dentmat', async (req: Request, res: Response) => {
  const db = req.db16;
  try {
    const raw = await db.raw(
      'select  s.*,c.catname,c.catnameth from mainproduct s,co_categories c where s.catid = c.catid limit 10'
    );
    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.no ok' });
    // res.send({ ok: false, message: 'Error Connect to Database iscc.' });
  }
  // res.send({ ok: false, message: 'Error Connect to Database is.' });
});
router.get('/tableshow', async (req: Request, res: Response) => {
  const db = req.db16;
  const tbl = req.params.tbl;
  try {
    const raw = await db.raw(`SHOW TABLES`);
    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.no ok' });
  }
  // res.send({ ok: false, message: 'Error Connect to Database is.' });
});
router.get('/tableshow/:tbl', async (req: Request, res: Response) => {
  const db = req.db16;
  const tbl = req.params.tbl;
  try {
    const raw = await db.raw(`SHOW FULL COLUMNS FROM ${tbl}`);
    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.no ok' });
  }
  // res.send({ ok: false, message: 'Error Connect to Database is.' });
});
router.get('/kn', async (req: Request, res: Response) => {
  const db = req.db16;
  try {
    const raw = await db('amp_36'); // db.raw('select * from amp_36');
    res.send({ ok: true, message: raw });
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.' });
  }
  // res.send({ ok: false, message: 'Error Connect to Database is.' });
});

router.get('/x/:a', async (req: Request, res: Response) => {
  const a = req.params.a;
  const db = req.db16;
  try {
    const raw = await db.raw(`select * from amp_36 where code='${a}'`);
    res.send({ ok: true, message: raw[0] });
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.' });
  }
  // res.send({ ok: false, message: 'Error Connect to Database is.' });
});

router.post('/', async (req: Request, res: Response) => {
  const db = req.db16;
  // let data = req.params.data;
  const data = req.body.data;
  try {
    const rows = await db('testnode').insert(data);
    res.send({ ok: true, message: rows });
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.' });
  }
  // res.send({ ok: false, message: 'Error Connect to Database is.' });
});

router.post('/dels', async (req: Request, res: Response) => {
  const db = req.db16;
  const data = req.body.data;
  try {
    const rows = await db('testnode').del().where(data);
    res.send({ ok: true, message: rows });
  } catch (error) {
    res.send({ ok: false, message: 'Error Connect to Database is.' });
  }
  // res.send({ ok: false, message: 'Error Connect to Database is.' });
});

router.get('/gen-token', async (req: Request, res: Response) => {
  try {
    const payload = {
      fullname: 'SATIT RIANPIT',
      username: 'satit',
      id: 1,
    };

    const token = jwt.signApiKey(payload);
    res.send({ ok: true, token: token, code: HttpStatus.OK });
  } catch (error) {
    res.send({
      ok: false,
      error: error.message,
      code: HttpStatus.INTERNAL_SERVER_ERROR,
    });
  }
});

export default router;
